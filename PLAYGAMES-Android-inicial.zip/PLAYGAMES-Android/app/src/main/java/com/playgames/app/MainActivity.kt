package com.playgames.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFE50935)
private val Muted = Color(0xFF9A9A9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PlayGamesApp() }
    }
}

private data class Game(val name: String, val emoji: String, val description: String)

@Composable
private fun PlayGamesApp() {
    var selected by remember { mutableStateOf<Game?>(null) }
    val games = listOf(
        Game("Xadrez", "♟", "Estratégia • 2 jogadores ou contra o computador"),
        Game("Damas", "⚫", "Estratégia • em desenvolvimento"),
        Game("Ludo", "🎲", "Diversão em grupo • em desenvolvimento"),
        Game("Sinuca", "🎱", "Precisão • em desenvolvimento")
    )

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Red,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selected == null) {
                Column(
                    Modifier.fillMaxSize().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text("PLAYGAMES", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("SEU UNIVERSO DE JOGOS", color = Red, fontSize = 11.sp, letterSpacing = 3.sp)
                    HorizontalDivider(color = Red.copy(alpha = 0.55f))
                    Text("CATÁLOGO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(games) { game ->
                            GameCard(game) { selected = game }
                        }
                    }
                    Text("BUILD 0.1.0  •  ANDROID", color = Muted, fontSize = 10.sp)
                }
            } else {
                GamePlaceholder(selected!!, onBack = { selected = null })
            }
        }
    }
}

@Composable
private fun GameCard(game: Game, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().height(150.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(game.emoji, fontSize = 34.sp, color = Red)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(game.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(game.description, color = Muted, fontSize = 10.sp, lineHeight = 13.sp)
        }
    }
}

@Composable
private fun GamePlaceholder(game: Game, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("‹  VOLTAR", color = Red, fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp))
        Text(game.emoji, fontSize = 48.sp)
        Text(game.name.uppercase(), fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text(
            if (game.name == "Xadrez") "O tabuleiro e a inteligência do computador serão implementados na próxima etapa."
            else "Este minijogo será implementado nas próximas versões.",
            color = Muted, fontSize = 14.sp
        )
        if (game.name == "Xadrez") {
            Text("MODO DE JOGO", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Red),
                modifier = Modifier.fillMaxWidth()) { Text("JOGAR CONTRA O COMPUTADOR") }
            OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Text("DOIS JOGADORES NO MESMO CELULAR")
            }
            Text("Esses botões são apenas a interface inicial; as partidas ainda não estão funcionais.",
                color = Muted, fontSize = 11.sp)
        }
    }
}
